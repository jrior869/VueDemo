import permission from "./module/permission";

export default {
  permission
}