<template>
    <div class="line">
        <page-layout>
            <a-card></a-card>
        </page-layout>
    </div>
</template>
<script>
export default{
    name:"line"
}
</script>