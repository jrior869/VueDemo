<template>
    <div class="space">
        <a-emtry></a-emtry>
    </div>
</template>
<script>
export default{
    name:"space"
}
</script>